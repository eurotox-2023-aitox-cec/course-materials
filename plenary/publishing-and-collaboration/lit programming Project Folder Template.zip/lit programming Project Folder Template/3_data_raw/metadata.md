place the .Rmd or .ipynb file with your paper and analyses in the main project folder. 
This file will link all information together.
