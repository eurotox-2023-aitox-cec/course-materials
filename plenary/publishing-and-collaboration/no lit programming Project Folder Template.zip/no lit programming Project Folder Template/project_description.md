information about the project
