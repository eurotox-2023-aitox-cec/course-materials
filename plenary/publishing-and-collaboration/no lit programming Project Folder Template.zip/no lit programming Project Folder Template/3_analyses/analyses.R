# Use the bannerCommenter package to create distinctive section headers
# https://cran.r-project.org/web/packages/bannerCommenter/vignettes/Banded_comment_maker.pdf